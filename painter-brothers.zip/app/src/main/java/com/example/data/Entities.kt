package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val phone: String,
    val name: String,
    val role: String, // "CUSTOMER", "PAINTER", "ADMIN"
    val profilePic: String = "", // Base64, local resource, or Uri
    val isOtpVerified: Boolean = false,
    val dateCreated: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "painter_profiles")
data class PainterProfileEntity(
    @PrimaryKey val painterPhone: String,
    val name: String,
    val photoUrl: String = "",
    val experienceYears: Int = 0,
    val skills: String = "", // Comma-separated: "Interior, Exterior, Putty, Texture, Waterproofing"
    val serviceArea: String = "",
    val hasActiveMembership: Boolean = false,
    val membershipPlanName: String = "", // "None", "Gold", "Platinum"
    val membershipExpiryDate: Long = 0,
    val averageRating: Float = 0f,
    val totalReviews: Int = 0
) : Serializable

@Entity(tableName = "jobs")
data class JobEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerPhone: String,
    val customerName: String,
    val title: String,
    val description: String,
    val workType: String, // "Interior", "Exterior", "Putty", "Texture", "Waterproofing"
    val imageUris: String = "", // Comma-separated list of image uris/drawables
    val locationAddress: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val status: String = "POSTED", // "POSTED", "ACCEPTED", "COMPLETED"
    val acceptedPainterPhone: String? = null,
    val acceptedPainterName: String? = null,
    val datePosted: Long = System.currentTimeMillis(),
    val dateCompleted: Long? = null
) : Serializable

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val jobId: Int,
    val painterPhone: String,
    val customerPhone: String,
    val customerName: String,
    val rating: Int, // 1 to 5
    val reviewText: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "complaints")
data class ComplaintEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val complainantPhone: String,
    val complainantName: String,
    val complainantRole: String, // "CUSTOMER", "PAINTER"
    val title: String,
    val description: String,
    val status: String = "PENDING", // "PENDING", "RESOLVED"
    val adminNotes: String = "",
    val timestamp: Long = System.currentTimeMillis()
) : Serializable
