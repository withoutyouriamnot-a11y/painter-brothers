package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // --- User Operations ---
    @Query("SELECT * FROM users WHERE phone = :phone LIMIT 1")
    suspend fun getUserByPhone(phone: String): UserEntity?

    @Query("SELECT * FROM users WHERE role = :role ORDER BY dateCreated DESC")
    fun getUsersByRole(role: String): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("DELETE FROM users WHERE phone = :phone")
    suspend fun deleteUserByPhone(phone: String)

    // --- Painter Profile Operations ---
    @Query("SELECT * FROM painter_profiles WHERE painterPhone = :phone LIMIT 1")
    suspend fun getPainterProfile(phone: String): PainterProfileEntity?

    @Query("SELECT * FROM painter_profiles WHERE painterPhone = :phone LIMIT 1")
    fun observePainterProfile(phone: String): Flow<PainterProfileEntity?>

    @Query("SELECT * FROM painter_profiles")
    fun getAllPainterProfiles(): Flow<List<PainterProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPainterProfile(profile: PainterProfileEntity)

    // --- Job Operations ---
    @Query("SELECT * FROM jobs ORDER BY datePosted DESC")
    fun getAllJobsFlow(): Flow<List<JobEntity>>

    @Query("SELECT * FROM jobs WHERE id = :jobId LIMIT 1")
    suspend fun getJobById(jobId: Int): JobEntity?

    @Query("SELECT * FROM jobs WHERE customerPhone = :customerPhone ORDER BY datePosted DESC")
    fun getJobsByCustomer(customerPhone: String): Flow<List<JobEntity>>

    @Query("SELECT * FROM jobs WHERE acceptedPainterPhone = :painterPhone ORDER BY datePosted DESC")
    fun getJobsByPainter(painterPhone: String): Flow<List<JobEntity>>

    @Query("SELECT * FROM jobs WHERE status = 'POSTED' ORDER BY datePosted DESC")
    fun getAvailableJobs(): Flow<List<JobEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: JobEntity)

    @Update
    suspend fun updateJob(job: JobEntity)

    @Query("DELETE FROM jobs WHERE id = :jobId")
    suspend fun deleteJobById(jobId: Int)

    // --- Review Operations ---
    @Query("SELECT * FROM reviews WHERE painterPhone = :painterPhone ORDER BY timestamp DESC")
    fun getReviewsForPainter(painterPhone: String): Flow<List<ReviewEntity>>

    @Query("SELECT * FROM reviews ORDER BY timestamp DESC")
    fun getAllReviews(): Flow<List<ReviewEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: ReviewEntity)

    // --- Complaint Operations ---
    @Query("SELECT * FROM complaints ORDER BY timestamp DESC")
    fun getAllComplaintsFlow(): Flow<List<ComplaintEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaint(complaint: ComplaintEntity)

    @Update
    suspend fun updateComplaint(complaint: ComplaintEntity)
}
