package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class CommissionReport(
    val jobId: Int,
    val jobTitle: String,
    val customerName: String,
    val painterName: String,
    val dateCompleted: Long,
    val estimatedAmount: Double,
    val commissionAmount: Double
)

class Repository private constructor(private val appDao: AppDao) {

    // Global in-memory flow to track current user
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    init {
        // Pre-populate an Admin user if none exists
        CoroutineScope(Dispatchers.IO).launch {
            val admin = appDao.getUserByPhone("9999999999")
            if (admin == null) {
                appDao.insertUser(
                    UserEntity(
                        phone = "9999999999",
                        name = "Admin Master",
                        role = "ADMIN",
                        profilePic = "admin_avatar",
                        isOtpVerified = true
                    )
                )
            }
            
            // Seed a few demo jobs and painters so the first experience is populated
            seedDemoData()
        }
    }

    // --- Authentication ---
    suspend fun loginWithOtp(phone: String, name: String, role: String): UserEntity = withContext(Dispatchers.IO) {
        val user = UserEntity(
            phone = phone,
            name = name,
            role = role,
            profilePic = if (role == "PAINTER") "painter_placeholder" else "customer_placeholder",
            isOtpVerified = true
        )
        appDao.insertUser(user)

        if (role == "PAINTER") {
            // Initialize basic painter profile if not existing
            val existingProfile = appDao.getPainterProfile(phone)
            if (existingProfile == null) {
                appDao.insertPainterProfile(
                    PainterProfileEntity(
                        painterPhone = phone,
                        name = name,
                        experienceYears = 3,
                        skills = "Interior, Putty",
                        serviceArea = "Downtown",
                        hasActiveMembership = false,
                        membershipPlanName = "None",
                        averageRating = 4.5f,
                        totalReviews = 1
                    )
                )
            }
        }

        _currentUser.value = user
        return@withContext user
    }

    suspend fun restoreSession(phone: String): Boolean = withContext(Dispatchers.IO) {
        val user = appDao.getUserByPhone(phone)
        if (user != null) {
            _currentUser.value = user
            return@withContext true
        }
        return@withContext false
    }

    fun logout() {
        _currentUser.value = null
    }

    // --- User management ---
    fun getAllCustomers(): Flow<List<UserEntity>> = appDao.getUsersByRole("CUSTOMER")
    fun getAllPainters(): Flow<List<UserEntity>> = appDao.getUsersByRole("PAINTER")
    
    suspend fun deleteUser(phone: String) = withContext(Dispatchers.IO) {
        appDao.deleteUserByPhone(phone)
    }

    // --- Painter Profiles ---
    suspend fun getPainterProfile(phone: String): PainterProfileEntity? = withContext(Dispatchers.IO) {
        return@withContext appDao.getPainterProfile(phone)
    }

    fun observePainterProfile(phone: String): Flow<PainterProfileEntity?> = appDao.observePainterProfile(phone)
    fun getAllPainterProfiles(): Flow<List<PainterProfileEntity>> = appDao.getAllPainterProfiles()

    suspend fun updatePainterProfile(profile: PainterProfileEntity) = withContext(Dispatchers.IO) {
        appDao.insertPainterProfile(profile)
    }

    // --- Membership Management ---
    suspend fun activateMembership(phone: String, plan: String) = withContext(Dispatchers.IO) {
        val currentProfile = appDao.getPainterProfile(phone)
        if (currentProfile != null) {
            val updated = currentProfile.copy(
                hasActiveMembership = true,
                membershipPlanName = plan,
                membershipExpiryDate = System.currentTimeMillis() + (if (plan == "Gold") 30L else 90L) * 24 * 60 * 60 * 1000
            )
            appDao.insertPainterProfile(updated)
        }
    }

    suspend fun cancelMembership(phone: String) = withContext(Dispatchers.IO) {
        val currentProfile = appDao.getPainterProfile(phone)
        if (currentProfile != null) {
            val updated = currentProfile.copy(
                hasActiveMembership = false,
                membershipPlanName = "None",
                membershipExpiryDate = 0
            )
            appDao.insertPainterProfile(updated)
        }
    }

    // --- Jobs ---
    fun getAvailableJobs(): Flow<List<JobEntity>> = appDao.getAvailableJobs()
    fun getJobsByCustomer(phone: String): Flow<List<JobEntity>> = appDao.getJobsByCustomer(phone)
    fun getJobsByPainter(phone: String): Flow<List<JobEntity>> = appDao.getJobsByPainter(phone)
    fun getAllJobsFlow(): Flow<List<JobEntity>> = appDao.getAllJobsFlow()

    suspend fun getJobById(jobId: Int): JobEntity? = withContext(Dispatchers.IO) {
        return@withContext appDao.getJobById(jobId)
    }

    suspend fun postJob(
        customerPhone: String,
        customerName: String,
        title: String,
        description: String,
        workType: String,
        imageUris: String,
        address: String,
        lat: Double,
        lng: Double
    ) = withContext(Dispatchers.IO) {
        val job = JobEntity(
            customerPhone = customerPhone,
            customerName = customerName,
            title = title,
            description = description,
            workType = workType,
            imageUris = imageUris,
            locationAddress = address,
            latitude = lat,
            longitude = lng,
            status = "POSTED"
        )
        appDao.insertJob(job)
    }

    suspend fun acceptJob(jobId: Int, painterPhone: String, painterName: String) = withContext(Dispatchers.IO) {
        val job = appDao.getJobById(jobId)
        if (job != null) {
            val updated = job.copy(
                status = "ACCEPTED",
                acceptedPainterPhone = painterPhone,
                acceptedPainterName = painterName
            )
            appDao.updateJob(updated)
        }
    }

    suspend fun rejectJob(jobId: Int) = withContext(Dispatchers.IO) {
        // Reset job status so others can accept
        val job = appDao.getJobById(jobId)
        if (job != null) {
            val updated = job.copy(
                status = "POSTED",
                acceptedPainterPhone = null,
                acceptedPainterName = null
            )
            appDao.updateJob(updated)
        }
    }

    suspend fun completeJob(jobId: Int) = withContext(Dispatchers.IO) {
        val job = appDao.getJobById(jobId)
        if (job != null) {
            val updated = job.copy(
                status = "COMPLETED",
                dateCompleted = System.currentTimeMillis()
            )
            appDao.updateJob(updated)
        }
    }

    suspend fun deleteJob(jobId: Int) = withContext(Dispatchers.IO) {
        appDao.deleteJobById(jobId)
    }

    // --- Ratings & Reviews ---
    fun getReviewsForPainter(phone: String): Flow<List<ReviewEntity>> = appDao.getReviewsForPainter(phone)
    fun getAllReviews(): Flow<List<ReviewEntity>> = appDao.getAllReviews()

    suspend fun submitReview(
        jobId: Int,
        painterPhone: String,
        customerPhone: String,
        customerName: String,
        rating: Int,
        reviewText: String
    ) = withContext(Dispatchers.IO) {
        val review = ReviewEntity(
            jobId = jobId,
            painterPhone = painterPhone,
            customerPhone = customerPhone,
            customerName = customerName,
            rating = rating,
            reviewText = reviewText
        )
        appDao.insertReview(review)

        // Recalculate average rating for painter
        appDao.getReviewsForPainter(painterPhone).firstOrNull()?.let { list ->
            val total = list.size + 1
            val sum = list.sumOf { it.rating } + rating
            val avg = sum.toFloat() / total
            
            val profile = appDao.getPainterProfile(painterPhone)
            if (profile != null) {
                appDao.insertPainterProfile(
                    profile.copy(
                        averageRating = avg,
                        totalReviews = total
                    )
                )
            }
        }
    }

    // --- Complaints ---
    fun getAllComplaints(): Flow<List<ComplaintEntity>> = appDao.getAllComplaintsFlow()

    suspend fun submitComplaint(
        phone: String,
        name: String,
        role: String,
        title: String,
        description: String
    ) = withContext(Dispatchers.IO) {
        val complaint = ComplaintEntity(
            complainantPhone = phone,
            complainantName = name,
            complainantRole = role,
            title = title,
            description = description,
            status = "PENDING"
        )
        appDao.insertComplaint(complaint)
    }

    suspend fun resolveComplaint(complaintId: Int, adminNotes: String) = withContext(Dispatchers.IO) {
        val all = appDao.getAllComplaintsFlow().firstOrNull()
        val found = all?.find { it.id == complaintId }
        if (found != null) {
            appDao.updateComplaint(
                found.copy(
                    status = "RESOLVED",
                    adminNotes = adminNotes
                )
            )
        }
    }

    // --- Commission Reports ---
    fun getCommissionReportsFlow(): Flow<List<CommissionReport>> {
        return appDao.getAllJobsFlow().map { jobs ->
            jobs.filter { it.status == "COMPLETED" }.map { job ->
                // Simulate job cost depending on title or random
                val estimatedAmount = when {
                    job.workType == "Interior" -> 1500.0
                    job.workType == "Exterior" -> 2500.0
                    job.workType == "Waterproofing" -> 1800.0
                    job.workType == "Putty" -> 800.0
                    else -> 1200.0
                }
                val commissionPercent = 0.10 // 10% commission
                CommissionReport(
                    jobId = job.id,
                    jobTitle = job.title,
                    customerName = job.customerName,
                    painterName = job.acceptedPainterName ?: "Unknown Painter",
                    dateCompleted = job.dateCompleted ?: job.datePosted,
                    estimatedAmount = estimatedAmount,
                    commissionAmount = estimatedAmount * commissionPercent
                )
            }
        }
    }

    // Seed demographic mock data for smooth onboarding
    private suspend fun seedDemoData() {
        val count = appDao.getAllPainterProfiles().firstOrNull()?.size ?: 0
        if (count == 0) {
            // Seed Painters
            appDao.insertUser(UserEntity("9876543210", "Rajesh Kumar", "PAINTER", "painter_1", true))
            appDao.insertPainterProfile(
                PainterProfileEntity(
                    painterPhone = "9876543210",
                    name = "Rajesh Kumar",
                    experienceYears = 8,
                    skills = "Interior, Exterior, Texture",
                    serviceArea = "Green Park, New Delhi",
                    hasActiveMembership = true,
                    membershipPlanName = "Platinum",
                    averageRating = 4.8f,
                    totalReviews = 12
                )
            )

            appDao.insertUser(UserEntity("8765432109", "Amit Singh", "PAINTER", "painter_2", true))
            appDao.insertPainterProfile(
                PainterProfileEntity(
                    painterPhone = "8765432109",
                    name = "Amit Singh",
                    experienceYears = 5,
                    skills = "Putty, Waterproofing",
                    serviceArea = "Saket, New Delhi",
                    hasActiveMembership = false,
                    membershipPlanName = "None",
                    averageRating = 4.2f,
                    totalReviews = 4
                )
            )

            // Seed Customers
            appDao.insertUser(UserEntity("7654321098", "Sunita Sharma", "CUSTOMER", "customer_1", true))

            // Seed Jobs
            appDao.insertJob(
                JobEntity(
                    customerPhone = "7654321098",
                    customerName = "Sunita Sharma",
                    title = "Interior Painting 3BHK",
                    description = "Need dynamic premium painting with plastic emulsion in 3 rooms and hallway. Putty work required only on one wall.",
                    workType = "Interior",
                    imageUris = "house_interior_1,house_interior_2",
                    locationAddress = "Block B, Saket, New Delhi",
                    latitude = 28.5244,
                    longitude = 77.2173,
                    status = "POSTED"
                )
            )

            appDao.insertJob(
                JobEntity(
                    customerPhone = "7654321098",
                    customerName = "Sunita Sharma",
                    title = "Building Exterior and Waterproofing",
                    description = "Double story home needs weather-proof paint on all exterior walls and roof waterproofing before the monsoon season starts.",
                    workType = "Exterior",
                    imageUris = "house_exterior_1",
                    locationAddress = "Sector 15, Gurgaon",
                    latitude = 28.4595,
                    longitude = 77.0266,
                    status = "POSTED"
                )
            )

            // Seed completed job for commission report
            appDao.insertJob(
                JobEntity(
                    customerPhone = "7654321098",
                    customerName = "Sunita Sharma",
                    title = "Living Room Texture & Putty",
                    description = "Metallic finish texture painting on living room feature wall.",
                    workType = "Texture",
                    imageUris = "house_texture_1",
                    locationAddress = "Vasant Kunj, New Delhi",
                    latitude = 28.5385,
                    longitude = 77.1593,
                    status = "COMPLETED",
                    acceptedPainterPhone = "9876543210",
                    acceptedPainterName = "Rajesh Kumar",
                    dateCompleted = System.currentTimeMillis() - 86400000
                )
            )

            // Seed Review
            appDao.insertReview(
                ReviewEntity(
                    jobId = 999,
                    painterPhone = "9876543210",
                    customerPhone = "7654321098",
                    customerName = "Sunita Sharma",
                    rating = 5,
                    reviewText = "Rajesh completed the texture wall beautifully! He was on-time, professional, and cleaned up everything after completing the work."
                )
            )
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: Repository? = null

        fun getRepository(context: Context): Repository {
            return INSTANCE ?: synchronized(this) {
                val database = AppDatabase.getDatabase(context)
                val instance = Repository(database.appDao())
                INSTANCE = instance
                instance
            }
        }
    }
}
