package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.MainViewModel
import com.example.ui.screens.*
import com.example.ui.theme.PainterBrothersTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PainterBrothersTheme {
                val navController = rememberNavController()
                val viewModel: MainViewModel = viewModel()

                NavHost(navController = navController, startDestination = "splash") {
                    composable("splash") {
                        SplashScreen(navController = navController)
                    }

                    composable("login") {
                        LoginScreen(viewModel = viewModel, navController = navController)
                    }

                    // Customer Navigation Nodes
                    composable("customer_home") {
                        CustomerHomeScreen(viewModel = viewModel, navController = navController)
                    }

                    composable("customer_post_job") {
                        PostJobScreen(viewModel = viewModel, navController = navController)
                    }

                    composable(
                        route = "job_details/{jobId}",
                        arguments = listOf(navArgument("jobId") { type = NavType.IntType })
                    ) { backStackEntry ->
                        val jobId = backStackEntry.arguments?.getInt("jobId") ?: 0
                        JobDetailScreen(jobId = jobId, viewModel = viewModel, navController = navController)
                    }

                    composable("customer_complaint") {
                        ComplaintScreen(viewModel = viewModel, navController = navController)
                    }

                    // Painter Navigation Nodes
                    composable("painter_home") {
                        PainterHomeScreen(viewModel = viewModel, navController = navController)
                    }

                    composable("painter_complaint") {
                        ComplaintScreen(viewModel = viewModel, navController = navController)
                    }

                    composable(
                        route = "reviews/{painterPhone}",
                        arguments = listOf(navArgument("painterPhone") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val painterPhone = backStackEntry.arguments?.getString("painterPhone") ?: ""
                        ReviewsScreen(painterPhone = painterPhone, viewModel = viewModel, navController = navController)
                    }

                    // Admin Panel Node
                    composable("admin_home") {
                        AdminHomeScreen(viewModel = viewModel, navController = navController)
                    }
                }
            }
        }
    }
}
