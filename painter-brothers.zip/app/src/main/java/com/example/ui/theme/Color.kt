package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PainterBlue = Color(0xFF023E8A) // Deep premium blue
val PainterLightBlue = Color(0xFFE0F2FE) // Soft background blue tint
val PainterOrange = Color(0xFFF97316) // Energetic orange accent (M3 orange)
val PainterDarkNavy = Color(0xFF0F172A) // Dark text and navy styling

// Light scheme palette
val LightPrimary = PainterBlue
val LightOnPrimary = Color.White
val LightPrimaryContainer = PainterLightBlue
val LightOnPrimaryContainer = Color(0xFF03045E)

val LightSecondary = Color(0xFF0077B6)
val LightOnSecondary = Color.White

val LightTertiary = PainterOrange
val LightOnTertiary = Color.White
val LightTertiaryContainer = Color(0xFFFFEDD5)
val LightOnTertiaryContainer = Color(0xFF7C2D12)

val LightBackground = Color(0xFFF8FAFC) // Slate 50 - clean, premium, crisp
val LightOnBackground = PainterDarkNavy
val LightSurface = Color.White
val LightOnSurface = PainterDarkNavy
val LightSurfaceVariant = Color(0xFFF1F5F9) // Slate 100
val LightOnSurfaceVariant = Color(0xFF475569) // Slate 600

// Dark scheme palette
val DarkPrimary = Color(0xFF38BDF8) // Light blue
val DarkOnPrimary = Color(0xFF03045E)
val DarkPrimaryContainer = Color(0xFF0369A1)
val DarkOnPrimaryContainer = Color(0xFFE0F2FE)

val DarkSecondary = Color(0xFF0EA5E9)
val DarkOnSecondary = Color(0xFF082F49)

val DarkTertiary = PainterOrange
val DarkOnTertiary = Color.White
val DarkTertiaryContainer = Color(0xFF9A3412)
val DarkOnTertiaryContainer = Color(0xFFFFEDD5)

val DarkBackground = Color(0xFF0F172A) // Slate 900
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkSurface = Color(0xFF1E293B) // Slate 800
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkSurfaceVariant = Color(0xFF334155) // Slate 700
val DarkOnSurfaceVariant = Color(0xFFCBD5E1) // Slate 300
