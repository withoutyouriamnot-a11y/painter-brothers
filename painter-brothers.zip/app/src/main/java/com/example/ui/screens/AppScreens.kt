package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.data.*
import com.example.ui.MainViewModel

// Global theme primary gradients & colors
private val NavyBlue = Color(0xFF023E8A)
private val LightNavy = Color(0xFF0077B6)
private val BrandOrange = Color(0xFFF97316)
private val SoftSlate = Color(0xFFF8FAFC)
private val MutedText = Color(0xFF475569)

// Dummy URLs or base64 descriptors for demo house images
private val DEMO_HOUSE_IMAGES = listOf(
    "Living Room (Walls prep)", "Master Bedroom (Putty applied)", "Kitchen Ceiling (Waterproofed)",
    "Front Exterior Entrance", "Balcony Wall (Texture paint)", "Staircase wall",
    "Kids room accent wall", "Garage door exterior", "Basement wall sealer", "Guest Room Paint"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(viewModel: MainViewModel, navController: NavController, currentRoute: String) {
    val currentUser by viewModel.currentUser.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(currentUser) {
        if (currentUser == null && currentRoute != "splash" && currentRoute != "login") {
            navController.navigate("login") {
                popUpTo(0) { inclusive = true }
            }
        }
    }
}

// ----------------------------------------------------
// 1. SPLASH SCREEN
// ----------------------------------------------------
@Composable
fun SplashScreen(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(NavyBlue, Color(0xFF0F172A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // App Logo Icon
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Brush,
                    contentDescription = "Logo Brush",
                    tint = BrandOrange,
                    modifier = Modifier.size(60.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "PAINTER BROTHERS",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Premium Painting Service On-Demand",
                fontSize = 14.sp,
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(48.dp))

            Button(
                onClick = { navController.navigate("login") },
                colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("get_started_button")
            ) {
                Text("Get Started", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

// ----------------------------------------------------
// 2. AUTH / LOGIN SCREEN WITH OTP
// ----------------------------------------------------
@Composable
fun LoginScreen(viewModel: MainViewModel, navController: NavController) {
    var phone by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var receivedOtp by remember { mutableStateOf<String?>(null) }
    var role by remember { mutableStateOf("CUSTOMER") } // "CUSTOMER", "PAINTER", "ADMIN"
    var isOtpRequested by remember { mutableStateOf(false) }

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SoftSlate)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Title Header
            Text(
                text = "Welcome to Painter Brothers",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Professional Painting Partners",
                fontSize = 14.sp,
                color = MutedText,
                modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Authentication Portal",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NavyBlue,
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Role Selector tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF1F5F9))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("CUSTOMER", "PAINTER", "ADMIN").forEach { selectedRole ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (role == selectedRole) NavyBlue else Color.Transparent)
                                    .clickable { role = selectedRole }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = selectedRole,
                                    color = if (role == selectedRole) Color.White else MutedText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (role == "ADMIN") {
                        Text(
                            text = "Admin Default Phone is: 9999999999. Simulated OTP bypass.",
                            fontSize = 11.sp,
                            color = BrandOrange,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    // Input Full Name
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name") },
                        placeholder = { Text("e.g. Ramesh Kumar") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_name_input"),
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = "Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Mobile Number Input
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Mobile Number") },
                        placeholder = { Text("10 digit number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_phone_input"),
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = "Phone") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                    )

                    if (isOtpRequested) {
                        Spacer(modifier = Modifier.height(12.dp))
                        // OTP Verification Input
                        OutlinedTextField(
                            value = otpCode,
                            onValueChange = { otpCode = it },
                            label = { Text("Verification OTP Code") },
                            placeholder = { Text("Enter 6-digit OTP code") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_otp_input"),
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "OTP") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    if (!isOtpRequested) {
                        Button(
                            onClick = {
                                viewModel.simulateOtpRequest(phone, context) { code ->
                                    receivedOtp = code
                                    isOtpRequested = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("request_otp_button")
                        ) {
                            Text("Request OTP", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = {
                                if (otpCode == receivedOtp || phone == "9999999999") {
                                    viewModel.login(phone, name, role, context) {
                                        if (role == "CUSTOMER") {
                                            navController.navigate("customer_home") { popUpTo("login") { inclusive = true } }
                                        } else if (role == "PAINTER") {
                                            navController.navigate("painter_home") { popUpTo("login") { inclusive = true } }
                                        } else {
                                            navController.navigate("admin_home") { popUpTo("login") { inclusive = true } }
                                        }
                                    }
                                } else {
                                    Toast.makeText(context, "Incorrect OTP Code. Please verify.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("verify_otp_button")
                        ) {
                            Text("Verify OTP & Login", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 3. CUSTOMER DASHBOARD SCREEN
// ----------------------------------------------------
@Composable
fun CustomerHomeScreen(viewModel: MainViewModel, navController: NavController) {
    val currentUser by viewModel.currentUser.collectAsState()
    val jobs by viewModel.jobsByCustomer.collectAsState()
    val painters by viewModel.allPainterProfiles.collectAsState()
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) } // 0: My Jobs, 1: Browse Painters

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyBlue)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Painter Brothers",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Customer Hub: ${currentUser?.name ?: "User"}",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }

                    Row {
                        IconButton(onClick = { navController.navigate("customer_complaint") }) {
                            Icon(Icons.Default.Warning, contentDescription = "Raise Complaint", tint = Color.White)
                        }
                        IconButton(onClick = {
                            viewModel.logout(context) {
                                navController.navigate("login") { popUpTo(0) { inclusive = true } }
                            }
                        }) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color.White)
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate("customer_post_job") },
                containerColor = BrandOrange,
                contentColor = Color.White,
                modifier = Modifier.testTag("post_job_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Post New Job")
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("My Jobs") }
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Painters") },
                    label = { Text("Nearby Painters") }
                )
            }
        },
        containerColor = SoftSlate
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (activeTab == 0) {
                // My Posted Jobs Tab
                if (jobs.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Empty",
                            tint = Color.LightGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No jobs posted yet!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MutedText
                        )
                        Text(
                            text = "Tap the '+' button below to post your house, building, or shop painting job.",
                            color = Color.Gray,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .padding(horizontal = 24.dp)
                                .padding(top = 8.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Your Painting Projects",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyBlue,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }

                        items(jobs) { job ->
                            JobCardCustomer(job = job, navController = navController)
                        }
                    }
                }
            } else {
                // Browse Nearby Painters Tab
                val listToShow = painters.filter { it.painterPhone != currentUser?.phone }
                if (listToShow.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No active painters available in your service area yet.", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Available Certified Painters Near You",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyBlue,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }

                        items(listToShow) { painter ->
                            PainterListCard(painter = painter, context = context, navController = navController)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JobCardCustomer(job: JobEntity, navController: NavController) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { navController.navigate("job_details/${job.id}") },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = job.workType.uppercase(),
                    color = BrandOrange,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                // Status Badge
                val (color, text) = when (job.status) {
                    "POSTED" -> Pair(Color(0xFFE2E8F0), "POSTED")
                    "ACCEPTED" -> Pair(Color(0xFFFEF08A), "ACCEPTED")
                    "COMPLETED" -> Pair(Color(0xFFBBF7D0), "COMPLETED")
                    else -> Pair(Color.LightGray, job.status)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(color)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = job.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = job.description,
                color = MutedText,
                fontSize = 13.sp,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = NavyBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(job.locationAddress, fontSize = 12.sp, color = MutedText)
            }

            if (job.status == "ACCEPTED" || job.status == "COMPLETED") {
                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Assigned Painter: ${job.acceptedPainterName ?: "Assigned"}",
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = NavyBlue
                    )

                    if (job.status == "COMPLETED") {
                        Button(
                            onClick = { navController.navigate("job_details/${job.id}") },
                            colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("Rate & Review", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PainterListCard(painter: PainterProfileEntity, context: Context, navController: NavController) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular Avatar with first letter
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(NavyBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = painter.name.take(1).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = painter.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = NavyBlue
                        )
                        if (painter.hasActiveMembership) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFFFEDD5))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    "VERIFIED",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BrandOrange
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(Icons.Default.Star, contentDescription = "Rating", tint = BrandOrange, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${painter.averageRating} (${painter.totalReviews} reviews)",
                            fontSize = 12.sp,
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "• Exp: ${painter.experienceYears} Years",
                            fontSize = 12.sp,
                            color = MutedText
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Skills: ${painter.skills}",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = NavyBlue
            )

            Text(
                text = "Service Area: ${painter.serviceArea}",
                fontSize = 12.sp,
                color = MutedText,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Reviews page trigger
                OutlinedButton(
                    onClick = { navController.navigate("reviews/${painter.painterPhone}") },
                    border = BorderStroke(1.dp, NavyBlue),
                    modifier = Modifier.height(38.dp)
                ) {
                    Text("Read Reviews", color = NavyBlue, fontSize = 12.sp)
                }

                // Call directly button (Requirement: Call painter directly, no chat)
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${painter.painterPhone}"))
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("call_painter_btn_${painter.painterPhone}")
                ) {
                    Icon(Icons.Default.Phone, contentDescription = "Call", tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call Now", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ----------------------------------------------------
// 4. POST JOB SCREEN (CUSTOMER)
// ----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostJobScreen(viewModel: MainViewModel, navController: NavController) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var workType by remember { mutableStateOf("Interior") } // "Interior", "Exterior", "Putty", "Texture", "Waterproofing"
    var photosList = remember { mutableStateListOf<String>() }

    val gpsAddress by viewModel.gpsAddress.collectAsState()
    val context = LocalContext.current

    val workTypes = listOf("Interior", "Exterior", "Putty", "Texture", "Waterproofing")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Post New Job Opportunity", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyBlue, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        },
        containerColor = SoftSlate
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Form Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Project Details", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyBlue)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Selection work type
                        Text("Work Category Type", fontSize = 12.sp, color = MutedText, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF1F5F9))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            workTypes.take(3).forEach { type ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (workType == type) BrandOrange else Color.Transparent)
                                        .clickable { workType = type }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = type,
                                        color = if (workType == type) Color.White else MutedText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF1F5F9))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            workTypes.drop(3).forEach { type ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (workType == type) BrandOrange else Color.Transparent)
                                        .clickable { workType = type }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = type,
                                        color = if (workType == type) Color.White else MutedText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("Project Title") },
                            placeholder = { Text("e.g. Paint 4-room bungalow") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("job_title_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Work Description & Materials") },
                            placeholder = { Text("Explain room details, wallpaper/putty needs, brand preference...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .testTag("job_desc_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                        )
                    }
                }
            }

            // Photo Upload Mandate Section (Customer mandate: upload 5 to 10 photos of house)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Upload House/Building Photos", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyBlue)
                                Text("Customer mandate: upload 5 to 10 photos", fontSize = 11.sp, color = BrandOrange)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (photosList.size in 5..10) Color(0xFFBBF7D0) else Color(0xFFFFD60A))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${photosList.size} of 10",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.DarkGray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Grid of attached photos
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    if (photosList.size >= 10) {
                                        Toast.makeText(context, "Limit: Maximum 10 photos", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    val nextImage = DEMO_HOUSE_IMAGES.random()
                                    photosList.add(nextImage)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                                modifier = Modifier
                                    .height(44.dp)
                                    .weight(1f)
                                    .testTag("add_photo_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Attach")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Attach Demo Photo", fontSize = 11.sp)
                            }

                            if (photosList.isNotEmpty()) {
                                Button(
                                    onClick = { photosList.clear() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    modifier = Modifier.height(44.dp)
                                ) {
                                    Text("Clear All", fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Show dynamic chips of attached photo simulations
                        if (photosList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(80.dp)
                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No house photos attached yet. (Mandatory: 5+)", color = Color.Gray, fontSize = 12.sp)
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                photosList.forEachIndexed { idx, name ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = "ok", tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Photo #${idx + 1}: $name", fontSize = 12.sp, color = Color.DarkGray)
                                        }

                                        IconButton(onClick = { photosList.removeAt(idx) }, modifier = Modifier.size(16.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "delete", tint = Color.Red, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // GPS Location Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Capture Geolocation (GPS)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyBlue)
                        Text("Fetch device coordinates to help painter map routes", fontSize = 11.sp, color = MutedText)

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = gpsAddress,
                            onValueChange = { viewModel.setManualAddress(it) },
                            label = { Text("Detected Address / Coordinates") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("gps_address_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { viewModel.captureGPS(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("gps_capture_btn")
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = "GPS")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Capture Location using GPS", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Final Submit CTA
            item {
                Button(
                    onClick = {
                        viewModel.postJob(
                            title = title,
                            description = description,
                            workType = workType,
                            images = photosList.toList(),
                            context = context
                        ) {
                            navController.navigateUp()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_job_btn"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Confirm & Post Job Opportunity", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

// ----------------------------------------------------
// 5. JOB DETAILS & SUBMIT REVIEW SCREEN
// ----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobDetailScreen(jobId: Int, viewModel: MainViewModel, navController: NavController) {
    val jobs by viewModel.allJobs.collectAsState()
    val job = jobs.find { it.id == jobId }
    val context = LocalContext.current

    var rating by remember { mutableStateOf(5) }
    var reviewText by remember { mutableStateOf("") }
    var ratingSubmitted by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Job Description Detail") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyBlue, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        },
        containerColor = SoftSlate
    ) { padding ->
        if (job == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Job details not found.", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Job Title Header Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = job.workType.uppercase(),
                                    color = BrandOrange,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFE2E8F0))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(job.status, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = job.title,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyBlue
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(text = "Posted by: ${job.customerName}", fontSize = 13.sp, color = MutedText, fontWeight = FontWeight.Medium)
                            Text(text = "Posted on: ${java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a").format(job.datePosted)}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                // Description Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Work Description", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = job.description, color = MutedText, fontSize = 14.sp, lineHeight = 20.sp)
                        }
                    }
                }

                // Photos Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("House Photos Attached (${job.imageUris.split(",").filter { it.isNotBlank() }.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                            Spacer(modifier = Modifier.height(12.dp))

                            val listPhotos = job.imageUris.split(",").filter { it.isNotBlank() }
                            if (listPhotos.isEmpty()) {
                                Text("No photo files available.", color = Color.Gray, fontSize = 13.sp)
                            } else {
                                listPhotos.forEachIndexed { idx, name ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Image, contentDescription = "Photo icon", tint = NavyBlue, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(name, fontSize = 12.sp, color = Color.DarkGray)
                                    }
                                }
                            }
                        }
                    }
                }

                // Location Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Work Site GPS Location", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = "Site", tint = BrandOrange, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(job.locationAddress, fontSize = 13.sp, color = MutedText)
                            }
                        }
                    }
                }

                // Assigned Painter Details / Direct Calling
                if (job.acceptedPainterPhone != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Assigned Professional Painter", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF166534))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(text = "Name: ${job.acceptedPainterName}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = "Phone: ${job.acceptedPainterPhone}", fontSize = 13.sp, color = MutedText)

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${job.acceptedPainterPhone}"))
                                        context.startActivity(intent)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandOrange)
                                ) {
                                    Icon(Icons.Default.Phone, contentDescription = "Call")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Call Painter Directly (Offline)")
                                }
                            }
                        }
                    }
                }

                // Submit Rating and Review if COMPLETED
                if (job.status == "COMPLETED" && job.acceptedPainterPhone != null && !ratingSubmitted) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BrandOrange),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Rate & Review Professional", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                                Text("Rate your experience after project completion", fontSize = 12.sp, color = MutedText)

                                Spacer(modifier = Modifier.height(12.dp))

                                // Dynamic Star selection
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    (1..5).forEach { num ->
                                        IconButton(onClick = { rating = num }) {
                                            Icon(
                                                imageVector = Icons.Default.Star,
                                                contentDescription = "$num Stars",
                                                tint = if (rating >= num) BrandOrange else Color.LightGray,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = reviewText,
                                    onValueChange = { reviewText = it },
                                    label = { Text("Your Review Note") },
                                    placeholder = { Text("Excellent finish, timely completed etc...") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                        .testTag("review_input"),
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        viewModel.submitReview(
                                            jobId = job.id,
                                            painterPhone = job.acceptedPainterPhone,
                                            rating = rating,
                                            reviewText = reviewText,
                                            context = context
                                        ) {
                                            ratingSubmitted = true
                                            navController.navigateUp()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("submit_review_btn")
                                ) {
                                    Text("Submit Feedback", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 6. PAINTER DASHBOARD SCREEN
// ----------------------------------------------------
@Composable
fun PainterHomeScreen(viewModel: MainViewModel, navController: NavController) {
    val currentUser by viewModel.currentUser.collectAsState()
    val availableJobs by viewModel.availableJobs.collectAsState()
    val myJobs by viewModel.jobsByPainter.collectAsState()
    val allPainterProfiles by viewModel.allPainterProfiles.collectAsState()

    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) } // 0: Available Jobs, 1: My Engagements, 2: Profile, 3: Membership

    val painterProfile = allPainterProfiles.find { it.painterPhone == currentUser?.phone }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyBlue)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Painter Brothers",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Painter Studio: ${currentUser?.name ?: "User"}",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }

                    Row {
                        IconButton(onClick = { navController.navigate("painter_complaint") }) {
                            Icon(Icons.Default.Warning, contentDescription = "Lodge Complaint", tint = Color.White)
                        }
                        IconButton(onClick = {
                            viewModel.logout(context) {
                                navController.navigate("login") { popUpTo(0) { inclusive = true } }
                            }
                        }) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color.White)
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.Work, contentDescription = "Jobs") },
                    label = { Text("Available") }
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Active") },
                    label = { Text("Engaged") }
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                    label = { Text("Profile") }
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(Icons.Default.Star, contentDescription = "Membership") },
                    label = { Text("Membership") }
                )
            }
        },
        containerColor = SoftSlate
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Check membership warning alert on job tabs
            if ((activeTab == 0 || activeTab == 1) && (painterProfile == null || !painterProfile.hasActiveMembership)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFFF7ED))
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = "Alert", tint = BrandOrange, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                "Membership Activation Required",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFFC2410C)
                            )
                            Text(
                                "Rule: Membership is mandatory before accepting jobs.",
                                fontSize = 11.sp,
                                color = Color(0xFF7C2D12)
                            )
                        }
                    }
                }
            }

            when (activeTab) {
                0 -> {
                    // Available Jobs Near Painter
                    if (availableJobs.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No jobs posted near your location currently.", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(availableJobs) { job ->
                                JobCardPainter(
                                    job = job,
                                    hasMembership = painterProfile?.hasActiveMembership ?: false,
                                    onAccept = { viewModel.acceptJob(job.id, context) },
                                    navController = navController
                                )
                            }
                        }
                    }
                }
                1 -> {
                    // Engaged / Accepted Jobs
                    val ongoing = myJobs.filter { it.status == "ACCEPTED" }
                    val completed = myJobs.filter { it.status == "COMPLETED" }

                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (ongoing.isNotEmpty()) {
                            item {
                                Text("Ongoing Job Commitments", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                            }
                            items(ongoing) { job ->
                                EngagedJobCard(
                                    job = job,
                                    context = context,
                                    onComplete = { viewModel.completeJob(job.id, context) },
                                    onRelease = { viewModel.rejectJob(job.id, context) }
                                )
                            }
                        }

                        if (completed.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Completed Contracts", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                            }
                            items(completed) { job ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(job.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text("Completed on: ${java.text.SimpleDateFormat("dd MMM yyyy").format(job.dateCompleted ?: job.datePosted)}", fontSize = 11.sp, color = Color.Gray)
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(0xFFDCFCE7))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text("COMPLETED", color = Color(0xFF15803D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        if (ongoing.isEmpty() && completed.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(200.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("You haven't accepted or completed any jobs yet.", color = Color.Gray)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Profile Setup & customization
                    PainterProfileSetupScreen(viewModel = viewModel, profile = painterProfile)
                }
                3 -> {
                    // Membership subscription
                    PainterMembershipScreen(viewModel = viewModel, profile = painterProfile)
                }
            }
        }
    }
}

@Composable
fun JobCardPainter(job: JobEntity, hasMembership: Boolean, onAccept: () -> Unit, navController: NavController) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = job.workType.uppercase(),
                    color = BrandOrange,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                Text(
                    text = "Nearby",
                    color = Color(0xFF10B981),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = job.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = job.description,
                color = MutedText,
                fontSize = 13.sp,
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = NavyBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(job.locationAddress, fontSize = 12.sp, color = MutedText)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(
                    onClick = { navController.navigate("job_details/${job.id}") },
                    border = BorderStroke(1.dp, NavyBlue)
                ) {
                    Text("Details", color = NavyBlue)
                }

                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                    modifier = Modifier.testTag("accept_job_btn_${job.id}")
                ) {
                    Text("Accept Job", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EngagedJobCard(job: JobEntity, context: Context, onComplete: () -> Unit, onRelease: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.dp, NavyBlue)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ONGOING CONTRACT",
                color = NavyBlue,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = job.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Customer: ${job.customerName}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Call customer (Direct Calling, no chat requirement)
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${job.customerPhone}"))
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = "Call", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Call Customer", fontSize = 11.sp)
                }

                Button(
                    onClick = onComplete,
                    colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Done", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mark Completed", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = onRelease,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                border = BorderStroke(1.dp, Color.Red),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Decline/Release Job", fontSize = 12.sp)
            }
        }
    }
}

// ----------------------------------------------------
// 6-A. PAINTER PROFILE SETUP SCREEN
// ----------------------------------------------------
@Composable
fun PainterProfileSetupScreen(viewModel: MainViewModel, profile: PainterProfileEntity?) {
    var experience by remember { mutableStateOf(profile?.experienceYears?.toString() ?: "3") }
    var serviceArea by remember { mutableStateOf(profile?.serviceArea ?: "") }

    val skillsList = listOf("Interior", "Exterior", "Putty", "Texture", "Waterproofing")
    val selectedSkills = remember { mutableStateListOf<String>() }

    val context = LocalContext.current

    LaunchedEffect(profile) {
        if (profile != null) {
            selectedSkills.clear()
            profile.skills.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach {
                selectedSkills.add(it)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Setup Painter Business Profile", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyBlue)
                    Text("Configure your painting expertise to gain client confidence", fontSize = 11.sp, color = MutedText)

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = experience,
                        onValueChange = { experience = it },
                        label = { Text("Years of Experience") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("painter_exp_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = serviceArea,
                        onValueChange = { serviceArea = it },
                        label = { Text("Service Area (e.g. South Delhi)") },
                        placeholder = { Text("Districts or areas you cover") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("painter_area_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Select Painting Skills", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                    Spacer(modifier = Modifier.height(8.dp))

                    skillsList.forEach { skill ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (selectedSkills.contains(skill)) {
                                        selectedSkills.remove(skill)
                                    } else {
                                        selectedSkills.add(skill)
                                    }
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = selectedSkills.contains(skill),
                                onCheckedChange = null,
                                colors = CheckboxDefaults.colors(checkedColor = NavyBlue)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(skill, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    val expVal = experience.toIntOrNull() ?: 3
                    viewModel.savePainterProfile(
                        experience = expVal,
                        skillsList = selectedSkills.toList(),
                        serviceArea = serviceArea,
                        context = context
                    ) {}
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("painter_save_profile_btn")
            ) {
                Text("Save Studio Profile Settings", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

// ----------------------------------------------------
// 6-B. PAINTER MEMBERSHIP CONTROL SCREEN
// ----------------------------------------------------
@Composable
fun PainterMembershipScreen(viewModel: MainViewModel, profile: PainterProfileEntity?) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Your Subscription Plan Status", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyBlue)
                Spacer(modifier = Modifier.height(12.dp))

                if (profile != null && profile.hasActiveMembership) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFDCFCE7))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text("ACTIVE: ${profile.membershipPlanName.uppercase()} PARTNER", fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                            Text("Commission-Free leads enabled.", fontSize = 12.sp, color = Color(0xFF166534))
                            Text("Expires on: ${java.text.SimpleDateFormat("dd MMM yyyy").format(profile.membershipExpiryDate)}", fontSize = 11.sp, color = Color(0xFF166534))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedButton(
                        onClick = { viewModel.cancelMembership(context) },
                        border = BorderStroke(1.dp, Color.Red),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cancel Subscription")
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFFEE2E2))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text("INACTIVE / NO MEMBERSHIP", fontWeight = FontWeight.Bold, color = Color(0xFFB91C1C))
                            Text("You cannot accept house paint contracts until you activate a membership plan.", fontSize = 11.sp, color = Color(0xFF991B1B))
                        }
                    }
                }
            }
        }

        Text("Select an Unlimited Partner Plan", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue, modifier = Modifier.align(Alignment.Start))

        // Gold Plan Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.subscribeMembership("Gold", context) },
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFFFD700))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Gold Sub-Plan (30 Days)", fontWeight = FontWeight.Bold, color = NavyBlue)
                    Text("Unlimited accepted leads, commission-free", fontSize = 11.sp, color = MutedText)
                    Text("Instant matching notification", fontSize = 11.sp, color = MutedText)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("$29.00", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BrandOrange)
                    Text("Choose", fontSize = 11.sp, color = NavyBlue)
                }
            }
        }

        // Platinum Plan Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.subscribeMembership("Platinum", context) },
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(2.dp, BrandOrange)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Platinum Unlimited (90 Days)", fontWeight = FontWeight.Bold, color = NavyBlue)
                    Text("Extended duration, Priority 1-hour notifications", fontSize = 11.sp, color = MutedText)
                    Text("Verified professional badge listing", fontSize = 11.sp, color = MutedText)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("$79.00", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BrandOrange)
                    Text("Popular Choice", fontSize = 10.sp, color = BrandOrange, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ----------------------------------------------------
// 7. COMPLAINT LOGGING SCREEN
// ----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplaintScreen(viewModel: MainViewModel, navController: NavController) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Log Service Complaint", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyBlue, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        },
        containerColor = SoftSlate
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "File a formal dispute or complaint regarding poor craftsmanship, payment gaps, or delay.",
                        fontSize = 13.sp,
                        color = MutedText
                    )

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Complaint Subject") },
                        placeholder = { Text("e.g. Paint quality issue or payment missing") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("complaint_title_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Detailed description of dispute") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .testTag("complaint_desc_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                    )
                }
            }

            Button(
                onClick = {
                    viewModel.submitComplaint(title, description, context) {
                        navController.navigateUp()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_complaint_btn")
            ) {
                Text("Log Complaint for Admin Action", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

// ----------------------------------------------------
// 8. REVIEWS VIEW SCREEN
// ----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewsScreen(painterPhone: String, viewModel: MainViewModel, navController: NavController) {
    val painters by viewModel.allPainterProfiles.collectAsState()
    val painter = painters.find { it.painterPhone == painterPhone }

    // Display a robust set of mock reviews for presentation and rating summaries
    val allReviews = remember(painterPhone) {
        listOf(
            ReviewEntity(
                id = 1, jobId = 100, painterPhone = painterPhone, customerPhone = "7654321098",
                customerName = "Sunita Sharma", rating = 5,
                reviewText = "Fantastic work done by the brothers! Clean coating, zero dust, perfect finish."
            ),
            ReviewEntity(
                id = 2, jobId = 101, painterPhone = painterPhone, customerPhone = "7654321091",
                customerName = "Ramesh Gupta", rating = 4,
                reviewText = "Highly skilled and professional. Used premium quality products as promised."
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Painter Performance Ratings") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyBlue, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        },
        containerColor = SoftSlate
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavyBlue)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(painter?.name ?: "Professional Painter", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = "Stars", tint = BrandOrange, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${painter?.averageRating ?: 4.5f} out of 5", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Text("${painter?.totalReviews ?: 2} customer ratings", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }

            item {
                Text("Client Testimonials", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue, modifier = Modifier.padding(top = 8.dp))
            }

            items(allReviews) { rev ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(rev.customerName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Row {
                                (1..5).forEach { starNum ->
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = "Rating Star",
                                        tint = if (rev.rating >= starNum) BrandOrange else Color.LightGray,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(rev.reviewText, fontSize = 12.sp, color = MutedText, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 9. ADMIN PANEL DASHBOARD
// ----------------------------------------------------
@Composable
fun AdminHomeScreen(viewModel: MainViewModel, navController: NavController) {
    val customers by viewModel.allCustomers.collectAsState()
    val painters by viewModel.allPainters.collectAsState()
    val jobs by viewModel.allJobs.collectAsState()
    val complaints by viewModel.allComplaints.collectAsState()
    val reports by viewModel.commissionReports.collectAsState()

    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) } // 0: Customers, 1: Painters, 2: Jobs, 3: Commission, 4: Complaints

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyBlue)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Painter Brothers Admin",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Central Command Control Console",
                            fontSize = 11.sp,
                            color = Color.LightGray
                        )
                    }

                    IconButton(onClick = {
                        viewModel.logout(context) {
                            navController.navigate("login") { popUpTo(0) { inclusive = true } }
                        }
                    }) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color.White)
                    }
                }
            }
        },
        bottomBar = {
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                containerColor = Color.White,
                edgePadding = 16.dp
            ) {
                Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Clients") })
                Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Painters") })
                Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("Jobs") })
                Tab(selected = activeTab == 3, onClick = { activeTab = 3 }, text = { Text("Commissions") })
                Tab(selected = activeTab == 4, onClick = { activeTab = 4 }, text = { Text("Disputes (${complaints.count { it.status == "PENDING" }})") })
            }
        },
        containerColor = SoftSlate
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (activeTab) {
                0 -> {
                    // Manage Customers Tab
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            Text("Registered Client Databases", fontWeight = FontWeight.Bold, color = NavyBlue, modifier = Modifier.padding(bottom = 6.dp))
                        }
                        if (customers.isEmpty()) {
                            item { Text("No client records found.", color = Color.Gray, fontSize = 13.sp) }
                        }
                        items(customers) { client ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(client.name, fontWeight = FontWeight.Bold, color = NavyBlue)
                                        Text(client.phone, fontSize = 12.sp, color = MutedText)
                                    }

                                    IconButton(onClick = { viewModel.deleteUserByAdmin(client.phone, context) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Manage Painters
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            Text("Registered Professional Painters", fontWeight = FontWeight.Bold, color = NavyBlue, modifier = Modifier.padding(bottom = 6.dp))
                        }
                        if (painters.isEmpty()) {
                            item { Text("No painters found.", color = Color.Gray, fontSize = 13.sp) }
                        }
                        items(painters) { painter ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(painter.name, fontWeight = FontWeight.Bold, color = NavyBlue)
                                        Text("Ph: ${painter.phone}", fontSize = 12.sp, color = MutedText)
                                    }

                                    IconButton(onClick = { viewModel.deleteUserByAdmin(painter.phone, context) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Manage Jobs
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            Text("All Job Postings Logs", fontWeight = FontWeight.Bold, color = NavyBlue, modifier = Modifier.padding(bottom = 6.dp))
                        }
                        if (jobs.isEmpty()) {
                            item { Text("No jobs posted yet in any category.", color = Color.Gray, fontSize = 13.sp) }
                        }
                        items(jobs) { job ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(job.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        IconButton(onClick = { viewModel.deleteJobByAdmin(job.id, context) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                                        }
                                    }

                                    Text("Client: ${job.customerName}", fontSize = 12.sp, color = MutedText)
                                    Text("Status: ${job.status}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BrandOrange)
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Commission reports
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("Commission and Leads Revenue Report", fontWeight = FontWeight.Bold, color = NavyBlue)
                            Text("Total 10% cut on all completed painter contracts", fontSize = 11.sp, color = MutedText)
                        }

                        val totalCommission = reports.sumOf { it.commissionAmount }
                        val totalBusiness = reports.sumOf { it.estimatedAmount }

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = BrandOrange)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("TOTAL ADMIN REVENUE EARNED", color = Color.White, fontSize = 12.sp)
                                    Text("$${"%.2f".format(totalCommission)}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Total Paint Volume: $${"%.2f".format(totalBusiness)} (10% cut)", color = Color.LightGray, fontSize = 11.sp)
                                }
                            }
                        }

                        item {
                            Text("Completed Projects Breakdown", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyBlue)
                        }

                        if (reports.isEmpty()) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    Text("No completed jobs reports available yet.", color = Color.Gray, fontSize = 13.sp)
                                }
                            }
                        }

                        items(reports) { rpt ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(rpt.jobTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("+$${"%.2f".format(rpt.commissionAmount)}", color = Color(0xFF166534), fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Contractor: ${rpt.painterName}", fontSize = 11.sp, color = MutedText)
                                        Text("Value: $${rpt.estimatedAmount}", fontSize = 11.sp, color = MutedText)
                                    }
                                }
                            }
                        }
                    }
                }
                4 -> {
                    // Manage Disputes / Complaints
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("Active Member Complaint Disputes", fontWeight = FontWeight.Bold, color = NavyBlue)
                        }

                        if (complaints.isEmpty()) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    Text("No disputes logged yet.", color = Color.Gray, fontSize = 13.sp)
                                }
                            }
                        }

                        items(complaints) { comp ->
                            var resolutionNotes by remember { mutableStateOf("") }

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(if (comp.status == "PENDING") Color(0xFFFEE2E2) else Color(0xFFDCFCE7))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(comp.status, color = if (comp.status == "PENDING") Color.Red else Color(0xFF15803D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Text(
                                            text = java.text.SimpleDateFormat("dd MMM yyyy").format(comp.timestamp),
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(comp.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyBlue)
                                    Text(comp.description, fontSize = 12.sp, color = MutedText, modifier = Modifier.padding(top = 4.dp))

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = "By: ${comp.complainantName} (${comp.complainantRole}) • Ph: ${comp.complainantPhone}",
                                        fontSize = 11.sp,
                                        color = MutedText,
                                        fontWeight = FontWeight.Medium
                                    )

                                    if (comp.status == "PENDING") {
                                        Spacer(modifier = Modifier.height(12.dp))

                                        OutlinedTextField(
                                            value = resolutionNotes,
                                            onValueChange = { resolutionNotes = it },
                                            label = { Text("Resolution Actions Notes") },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(70.dp),
                                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NavyBlue)
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Button(
                                            onClick = { viewModel.resolveComplaint(comp.id, resolutionNotes, context) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF166534)),
                                            modifier = Modifier.align(Alignment.End)
                                        ) {
                                            Text("Resolve Dispute", color = Color.White)
                                        }
                                    } else {
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                                        Text("Admin Resolution Notes:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF15803D))
                                        Text(comp.adminNotes, fontSize = 12.sp, color = Color.DarkGray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
