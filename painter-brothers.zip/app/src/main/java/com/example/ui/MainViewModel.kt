package com.example.ui

import android.app.Application
import android.content.Context
import android.location.Location
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = Repository.getRepository(application)

    // Current session status
    val currentUser: StateFlow<UserEntity?> = repository.currentUser

    // Customer states
    private val _jobsByCustomer = MutableStateFlow<List<JobEntity>>(emptyList())
    val jobsByCustomer: StateFlow<List<JobEntity>> = _jobsByCustomer.asStateFlow()

    // Painter states
    private val _jobsByPainter = MutableStateFlow<List<JobEntity>>(emptyList())
    val jobsByPainter: StateFlow<List<JobEntity>> = _jobsByPainter.asStateFlow()

    val allPainterProfiles: StateFlow<List<PainterProfileEntity>> = repository.getAllPainterProfiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Available jobs near painter
    val availableJobs: StateFlow<List<JobEntity>> = repository.getAvailableJobs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin states
    val allCustomers: StateFlow<List<UserEntity>> = repository.getAllCustomers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPainters: StateFlow<List<UserEntity>> = repository.getAllPainters()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allJobs: StateFlow<List<JobEntity>> = repository.getAllJobsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allComplaints: StateFlow<List<ComplaintEntity>> = repository.getAllComplaints()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val commissionReports: StateFlow<List<CommissionReport>> = repository.getCommissionReportsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // GPS & Location Simulator State
    private val _gpsLocation = MutableStateFlow<Pair<Double, Double>?>(null)
    val gpsLocation: StateFlow<Pair<Double, Double>?> = _gpsLocation.asStateFlow()

    private val _gpsAddress = MutableStateFlow("")
    val gpsAddress: StateFlow<String> = _gpsAddress.asStateFlow()

    init {
        // Automatically fetch jobs when user details change
        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null) {
                    if (user.role == "CUSTOMER") {
                        repository.getJobsByCustomer(user.phone).collect { list ->
                            _jobsByCustomer.value = list
                        }
                    } else if (user.role == "PAINTER") {
                        repository.getJobsByPainter(user.phone).collect { list ->
                            _jobsByPainter.value = list
                        }
                    }
                }
            }
        }
    }

    // --- OTP Login / Auth Simulation ---
    fun simulateOtpRequest(phone: String, context: Context, onCodeSent: (String) -> Unit) {
        if (phone.length < 10) {
            Toast.makeText(context, "Please enter a valid 10-digit mobile number", Toast.LENGTH_SHORT).show()
            return
        }
        val simulatedCode = (100000..999999).random().toString()
        onCodeSent(simulatedCode)
        Toast.makeText(context, "[Firebase SMS] OTP sent: $simulatedCode", Toast.LENGTH_LONG).show()
    }

    fun login(phone: String, name: String, role: String, context: Context, onSuccess: () -> Unit) {
        if (name.isBlank() || phone.isBlank()) {
            Toast.makeText(context, "Fields cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }
        viewModelScope.launch {
            repository.loginWithOtp(phone, name, role)
            Toast.makeText(context, "Logged in successfully as $role", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
    }

    fun logout(context: Context, onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            repository.logout()
            Toast.makeText(context, "Logged out", Toast.LENGTH_SHORT).show()
            onLoggedOut()
        }
    }

    // --- GPS Simulation ---
    fun captureGPS(context: Context) {
        // In physical emulators GPS requests might be slow.
        // We simulate precision GPS capturing for seamless user feedback.
        viewModelScope.launch {
            val randomLat = 28.50 + (0.10 * Math.random())
            val randomLng = 77.10 + (0.20 * Math.random())
            _gpsLocation.value = Pair(randomLat, randomLng)
            _gpsAddress.value = "New Delhi, India (GPS Lat: ${"%.4f".format(randomLat)}, Lng: ${"%.4f".format(randomLng)})"
            Toast.makeText(context, "Location fetched successfully via GPS!", Toast.LENGTH_SHORT).show()
        }
    }

    fun setManualAddress(address: String) {
        _gpsAddress.value = address
    }

    // --- Customer Job Posting ---
    fun postJob(
        title: String,
        description: String,
        workType: String,
        images: List<String>,
        context: Context,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value
        if (user == null) {
            Toast.makeText(context, "Session expired, please login again", Toast.LENGTH_SHORT).show()
            return
        }
        if (title.isBlank() || description.isBlank() || workType.isBlank()) {
            Toast.makeText(context, "Please fill in all job details", Toast.LENGTH_SHORT).show()
            return
        }
        if (images.size < 5) {
            Toast.makeText(context, "User mandate: Please upload at least 5 house photos (current: ${images.size})", Toast.LENGTH_LONG).show()
            return
        }

        viewModelScope.launch {
            val address = _gpsAddress.value.ifBlank() { "South Extension, New Delhi" }
            val lat = _gpsLocation.value?.first ?: 28.52
            val lng = _gpsLocation.value?.second ?: 77.21

            // Join image references/uris
            val imagesCsv = images.joinToString(",")

            repository.postJob(
                customerPhone = user.phone,
                customerName = user.name,
                title = title,
                description = description,
                workType = workType,
                imageUris = imagesCsv,
                address = address,
                lat = lat,
                lng = lng
            )
            Toast.makeText(context, "Job Posted Successfully!", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
    }

    // --- Painter Profile Customization ---
    fun savePainterProfile(
        experience: Int,
        skillsList: List<String>,
        serviceArea: String,
        context: Context,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val skills = skillsList.joinToString(", ")
            val currentProfile = repository.getPainterProfile(user.phone)
            val updated = PainterProfileEntity(
                painterPhone = user.phone,
                name = user.name,
                photoUrl = "painter_avatar",
                experienceYears = experience,
                skills = skills,
                serviceArea = serviceArea,
                hasActiveMembership = currentProfile?.hasActiveMembership ?: false,
                membershipPlanName = currentProfile?.membershipPlanName ?: "None",
                membershipExpiryDate = currentProfile?.membershipExpiryDate ?: 0,
                averageRating = currentProfile?.averageRating ?: 4.5f,
                totalReviews = currentProfile?.totalReviews ?: 1
            )
            repository.updatePainterProfile(updated)
            Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
    }

    // --- Painter Job Accept / Reject ---
    fun acceptJob(jobId: Int, context: Context) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val profile = repository.getPainterProfile(user.phone)
            if (profile == null || !profile.hasActiveMembership) {
                Toast.makeText(context, "Mandatory rule: Active membership subscription is required to accept jobs!", Toast.LENGTH_LONG).show()
                return@launch
            }

            repository.acceptJob(jobId, user.phone, user.name)
            Toast.makeText(context, "Job accepted successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    fun rejectJob(jobId: Int, context: Context) {
        viewModelScope.launch {
            repository.rejectJob(jobId)
            Toast.makeText(context, "Job declined/released", Toast.LENGTH_SHORT).show()
        }
    }

    fun completeJob(jobId: Int, context: Context) {
        viewModelScope.launch {
            repository.completeJob(jobId)
            Toast.makeText(context, "Great work! Job marked as completed.", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Membership Purchasing ---
    fun subscribeMembership(plan: String, context: Context) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.activateMembership(user.phone, plan)
            Toast.makeText(context, "Membership activated! You can now accept painter jobs.", Toast.LENGTH_SHORT).show()
        }
    }

    fun cancelMembership(context: Context) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.cancelMembership(user.phone)
            Toast.makeText(context, "Membership cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Rating / Review Submission ---
    fun submitReview(jobId: Int, painterPhone: String, rating: Int, reviewText: String, context: Context, onSuccess: () -> Unit) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.submitReview(
                jobId = jobId,
                painterPhone = painterPhone,
                customerPhone = user.phone,
                customerName = user.name,
                rating = rating,
                reviewText = reviewText
            )
            Toast.makeText(context, "Review submitted. Thank you!", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
    }

    // --- Complaints submission ---
    fun submitComplaint(title: String, description: String, context: Context, onSuccess: () -> Unit) {
        val user = currentUser.value ?: return
        if (title.isBlank() || description.isBlank()) {
            Toast.makeText(context, "Please complete the complaint fields", Toast.LENGTH_SHORT).show()
            return
        }
        viewModelScope.launch {
            repository.submitComplaint(
                phone = user.phone,
                name = user.name,
                role = user.role,
                title = title,
                description = description
            )
            Toast.makeText(context, "Complaint logged. Admin will review.", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
    }

    // --- Admin Dashboard management ---
    fun resolveComplaint(complaintId: Int, notes: String, context: Context) {
        viewModelScope.launch {
            repository.resolveComplaint(complaintId, notes)
            Toast.makeText(context, "Complaint resolved", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteUserByAdmin(phone: String, context: Context) {
        viewModelScope.launch {
            repository.deleteUser(phone)
            Toast.makeText(context, "User profile and credentials deleted by admin", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteJobByAdmin(jobId: Int, context: Context) {
        viewModelScope.launch {
            repository.deleteJob(jobId)
            Toast.makeText(context, "Job deleted by admin", Toast.LENGTH_SHORT).show()
        }
    }
}
